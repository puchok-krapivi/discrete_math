def open_file(matrica):
    f = open('m8.txt')
    for line in f:
        line = line.split(' ')
        new_line = []
        for elem in line:
            if len(elem) > 1:
                elem = elem[0]
            new_line.append(elem)
        matrica.append(new_line)
    print('Введенная матрица')
    for elem in matrica:
        print(elem)


def simmetriya(matrica):
    check_1 = 1  # симметрия(0-нет, 1-да)
    check_2 = 1  # антисимметрия(0-нет, 1-да)
    check_3 = 1  # ассимметрия(0-нет, 1-да)
    print('Симметричность?')
    for i in range(len(matrica)):
        for j in range(len(matrica[i])):
            if i != j:
                if matrica[i][j] != matrica[j][i]:
                    check_1 = 0
                    break
        if check_1 == 0:
            print('Нет')
            break
    if check_1 == 1:
        print('Да')
    print('Антисимметричность?')
    for i in range(len(matrica)):
        for j in range(len(matrica[i])):
            if i != j:
                if check_2 == 1:
                    if matrica[i][j] == '1':
                        if matrica[j][i] == '0':
                            check_2 = 1
                        else:
                            check_2 = 0
    answer = 0
    if check_2 == 1:
        for i in range(len(matrica)):
            for j in range(len(matrica[i])):
                if i == j:
                    if matrica[i][j] == '1':
                        check_2 = 1
                        answer = 1
                    else:
                        if answer == 0:
                            check_2 = 0
    if check_2 == 0:
        print('Нет')
    else:
        print('Да')
    print('Ассимметричность?')
    for i in range(len(matrica)):
        for j in range(len(matrica[i])):
            if i != j:
                if matrica[i][j] == matrica[j][i]:
                    check_3 = 0
                    break
        if check_3 == 0:
            break
    if check_3 == 1:
        for i in range(len(matrica)):
            for j in range(len(matrica[i])):
                if i == j:
                    if matrica[i][j] == '1':
                        check_3 = 0
    if check_3 == 0:
        print('Нет')
    else:
        print('Да')


def reflectivnost(matrica):
    check_4 = 0  # рефлексивность (0-нет, 1-да, 3-антирефл)
    print('Рефлексивность?')
    for i in range(len(matrica)):
        for j in range(len(matrica[i])):
            if i == j:
                if matrica[i][j] == '0' and matrica[j][i] == '0':
                    if check_4 == 0 or check_4 == 3:
                        check_4 = 3
                    else:
                        check_4 = 1
                elif matrica[i][j] == '1' and matrica[j][i] == '1':
                    if check_4 == 0 or check_4 == 2:
                        check_4 = 2
                    else:
                        check_4 = 1
                else:
                    check_4 = 1
                    break
    if check_4 == 2:
        print('Да')
    else:
        print('Нет')
    print('Антирефлексивность?')
    if check_4 == 3:
        print('Да')
    else:
        print('Нет')


def transitivnost(matrica):
    n = 6
    answer = 0
    for i in range(n):
        for j in range(n):
            if matrica[i][j] == '1':
                for k in range(n):
                    if matrica[j][k] == '1':
                        if not matrica[i][k] == '1':
                            check_5 = 0
                            answer = 1
    if answer == 0:
        check_5 = 1
    print('Транзитивность?')
    if check_5 == 0:
        print('Нет')
    else:
        print('Да')


def polnota(matrica):
    check_6 = 1
    for i in range(len(matrica)):
        for j in range(i, len(matrica[i])):
            if i != j:
                if matrica[i][j] == '0' and matrica[j][i] == '0':
                    check_6 = 0
    print('Полнота?')
    if check_6 == 1:
        print('Да')
    else:
        print('Нет')


matrica = []
open_file(matrica)
print('********************')
reflectivnost(matrica)
print('********************')
simmetriya(matrica)
print('********************')
transitivnost(matrica)
print('********************')
polnota(matrica)
