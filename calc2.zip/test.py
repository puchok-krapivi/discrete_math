def open_file(matrica):
    f = open('m8.txt')
    for line in f:
        line = line.split(' ')
        new_line = []
        for elem in line:
            if len(elem) > 1:
                elem = elem[0]
            new_line.append(elem)
        matrica.append(new_line)
    print('Введенная матрица')
    for elem in matrica:
        print(elem)

def polnota(matrica):
    check_6 = 1
    for i in range(len(matrica)):
        for j in range(i, len(matrica[i])):
            if i != j:
                if matrica[i][j] == '0' and matrica[j][i] == '0':
                    check_6 = 0
    if check_6 == 1:
        print('Да')
    else:
        print('Нет')




matrica = []
open_file(matrica)
polnota(matrica)