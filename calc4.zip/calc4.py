import pandas as pd

f = open("vectors.txt", "r")

sec_exists = False
th_exists = False

string = f.readline()
first_func = [int(i) for i in string.split(' ')]

string = f.readline()
if (len(string) != 0):
    second_func = [int(i) for i in string.split(' ')]
    sec_exists = True

string = f.readline()
if (len(string) != 0):
    third_func = [int(j) for j in string.split(' ')]
    th_exists = True


def corr(a):
    length = len(a)
    if (length not in [1, 2, 4, 8]):
        return 0
    return 1


def check_zero(a):
    return not a[0]


def check_one(a):
    return a[len(a) - 1] == 1


def check_selfduality(a):
    if (len(a) == 1):
        return False
    for i in range(len(a) // 2):
        if ((a[len(a) - i - 1] + a[i]) % 2 == 0):
            return False
    return True


def check_linearity(a):
    if (len(a) < 4):
        return True
    if (len(a) == 4):
        return not (sum(a) % 2)
    yz = ((a[0] + a[1] + a[2] + a[3]) % 2)
    xz = ((a[0] + a[1] + a[4] + a[5]) % 2)
    xy = ((a[0] + a[2] + a[4] + a[6]) % 2)
    xyz = (sum(a) % 2)
    if not (yz or xz or xy or xyz):
        return True
    return False


def check_monotony(a):
    if (len(a) == 1):
        return True
    if (len(a) == 2):
        return a[0] <= a[1]
    if (len(a) == 4):
        return a[0] <= a[1] and a[0] <= a[2] and a[1] <= a[3] and a[2] <= a[3]
    if a[0] > a[1] or a[0] > a[2] or a[0] > a[4]:
        return False
    if a[1] > a[3] or a[1] > a[5] or a[2] > a[3] or a[2] > a[6] or a[4] > a[5] or a[4] > a[6]:
        return False
    if a[3] > a[7] or a[5] > a[7] or a[6] > a[7]:
        return False
    return True


def check_completeness(t, s):
    for i in range(4):
        if (s == 2):
            if (t[0][i] and t[1][i] and t[2][i]):
                return False
        if (s == 1):
            if (t[0][i] and t[1][i]):
                return False
        if (s == 0):
            if (t[0][i]):
                return False
    return True


result = corr(first_func)
if (th_exists):
    result = result and corr(third_func)
if (sec_exists):
    result = result and corr(second_func)
if (result):
    if (th_exists & sec_exists):
        table = [
            [check_zero(first_func), check_one(first_func), check_selfduality(first_func), check_linearity(first_func),
             check_monotony(first_func)],
            [check_zero(second_func), check_one(second_func), check_selfduality(second_func),
             check_linearity(second_func), check_monotony(second_func)],
            [check_zero(third_func), check_one(third_func), check_selfduality(third_func), check_linearity(third_func),
             check_monotony(third_func)]]
        df = pd.DataFrame(table, ["F1", "F2", "F3"], ["T0", "T1", "S", "L", "M"])
        print(df)
    if (sec_exists and not th_exists):
        table = [
            [check_zero(first_func), check_one(first_func), check_selfduality(first_func), check_linearity(first_func),
             check_monotony(first_func)],
            [check_zero(second_func), check_one(second_func), check_selfduality(second_func),
             check_linearity(second_func), check_monotony(second_func)]]
        df = pd.DataFrame(table, ["F1", "F2"], ["T0", "T1", "S", "L", "M"])
        print(df)
    if (not sec_exists and not th_exists):
        table = [
            [check_zero(first_func), check_one(first_func), check_selfduality(first_func), check_linearity(first_func),
             check_monotony(first_func)]]
        df = pd.DataFrame(table, ["F1"], ["T0", "T1", "S", "L", "M"])
        print(df)
if (th_exists and sec_exists):
    print("Полнота системы:", check_completeness(table, 2))
elif (sec_exists and not th_exists):
    print("Полнота системы:", check_completeness(table, 1))
elif (not sec_exists and not th_exists):
    print("Полнота системы:", check_completeness(table, 0))
